import React, { useState } from 'react';
import MenuList from './menu-list';
import {FaMinus, FaPlus} from 'react-icons/fa';

const MenuItem = ({item}) => {

    const [displayCurChil, setDisplayCurChil] = useState({});

    function handleToggleChil(getCurId) {
        setDisplayCurChil({
            ...displayCurChil, 
            [getCurId] : !displayCurChil[getCurId],
        });
        
    }


  return (
    <li>
     <div className='menu-item'>
     <p>{item.name}</p>
     {
        item && item.children && item.children.length 
        ? <span onClick={()=>handleToggleChil(item.id)}>
            {
                displayCurChil[item.id] ? <FaMinus color='#fff' size={25}/> : <FaPlus color='#fff' size={25} />
            }
        </span>
        : null
     }
     </div>
      {
        item && item.children && item.children.length > 0 && displayCurChil[item.id]
        ? <MenuList list={item.children} />
        : null
      }
    </li>
  )
}

export default MenuItem
