import React from 'react';
import MenuList from './menu-list';
import './style.css';

const TreeView = ({sideMenu = []}) => {
  return (
    <div className='tree-view-container'> 
    
    <MenuList list={sideMenu} />
      
    </div>
  )
}

export default TreeView;
