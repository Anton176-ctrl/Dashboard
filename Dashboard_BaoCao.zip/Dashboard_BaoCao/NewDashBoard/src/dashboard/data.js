export const sideMenu = [
    {
      "id": 1,
      "name": "Trang chủ",
      "url": "/home",
      "children": []
    },
    {
      "id": 2,
      "name": "Quản lý hệ thống",
      "url": "/quan-ly-he-thong",
      "children": [
        {
          "id": 3,
          "name": "Quản lý người dùng",
          "url": "/quan-ly-nguoi-dung",
          "children": [
            {
              "id": 4,
              "name": "Danh sách người dùng",
              "url": "/danh-sach-nguoi-dung",
              "children": []
            },
            {
              "id": 5,
              "name": "Nhóm người dùng",
              "url": "/nhom-nguoi-dung",
              "children": []
            },
            {
              "id": 6,
              "name": "Phân quyền người dùng",
              "url": "/phan-quyen-nguoi-dung",
              "children": []
            }
          ]
        },
        {
          "id": 7,
          "name": "Danh mục hệ thống",
          "url": "/danh-muc-he-thong",
          "children": [
            {
              "id": 8,
              "name": "Nhóm chức năng",
              "url": "/nhom-chuc-nang",
              "children": []
            },
            {
              "id": 9,
              "name": "Chức năng",
              "url": "/chuc-nang",
              "children": []
            }
          ]
        }
      ]
    },
    {
      "id": 10,
      "name": "Hành chánh",
      "url": "/hanh-chanh",
      "children": [
        {
          "id": 11,
          "name": "Danh mục hành chánh",
          "url": "/danh-muc-hanh-chanh",
          "children": [
            {
              "id": 12,
              "name": "Bộ phận",
              "url": "/bo-phan",
              "children": []
            },
            {
              "id": 13,
              "name": "Chức vụ",
              "url": "/chuc-vu",
              "children": []
            }
          ]
        },
        {
          "id": 15,
          "name": "Thông tin nhân sự",
          "url": "/thong-tin-nhan-su",
          "children": [
            {
              "id": 16,
              "name": "Hồ sơ nhân viên",
              "url": "/ho-so-nhan-vien",
              "children": [{
                "id": 17,
                "name": "Hồ sơ nhân viên",
                "url": "/ho-so-nhan-vien",
                "children": []
              }]
            }
          ]
        }
      ]
    }
  ]

  export default sideMenu;