import React from 'react';
import { useState } from 'react';
import Home from './Home';
import Header from './Header';
import Sidebar from './Sidebar';
import sideMenu from './data';


const Main = () => {
  
    const [openSidebarToggle, setOpenSidebarToggle] = useState(true)

    const OpenSidebar = () => {
      setOpenSidebarToggle(!openSidebarToggle)
    }
  return (
    <div className='grid-container'>
      <Header OpenSidebar={OpenSidebar}/>
      <Sidebar openSidebarToggle={openSidebarToggle} OpenSidebar={OpenSidebar} sideMenu={sideMenu}/>
      <Home />
    </div>
  )
}

export default Main
