import React, { useState } from 'react';
import MenuList from './menu-list';
import {FaMinus, FaPlus} from 'react-icons/fa';

const MenuItem = ({item}) => {

    const [displayCurChil, setDisplayCurChil] = useState({});

    function handleToggleChil(getCurId) {
        setDisplayCurChil({
            ...displayCurChil, 
            [getCurId] : !displayCurChil[getCurId],
        });
        
    }


  return (
    <li className='sidebar-list-item'>
     <div className='menu-item-content'>
     <p className='menu-item-text'>{item.name}</p>
     {
        item && item.children && item.children.length 
        ? <span onClick={()=>handleToggleChil(item.id)} className='icon-toggle'>
            {
                displayCurChil[item.id] ? <FaMinus color='#fff' size={15}/> : <FaPlus color='#fff' size={15} />
            }
        </span>
        : null
     }
     </div>
      {
        item && item.children && item.children.length > 0 && displayCurChil[item.id]
        ? <MenuList list={item.children} />
        : null
      }
    </li>
  )
}

export default MenuItem
