import React from 'react';
import MenuItem from './menu-item';

const MenuList = ({list = []}) => {
  console.log('MenuList received:', list);
  return (
    
    <ul className='sidebar-list'>
            {
          list && list.length 
          ? list.map(listItem=> <MenuItem item={listItem} />)
          : null}
           
        </ul> 
  )
}

export default MenuList
