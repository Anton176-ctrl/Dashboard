import React from 'react'
import 
{BsGrid1X2Fill}
 from 'react-icons/bs';
 import MenuList from './menu-list';
 

 function Sidebar({ openSidebarToggle, OpenSidebar, sideMenu = [] }) {
    console.log('sideMenu in Sidebar:', sideMenu);
    return (
      <aside id="sidebar" className={openSidebarToggle ? "sidebar-responsive" : ""}>
        <div className="sidebar-title">
          <div className="sidebar-brand">
            <BsGrid1X2Fill className="icon" /> DASHBOARD
          </div>
          <span className="icon close_icon" onClick={OpenSidebar}>X</span>
        </div>
  
        <MenuList list={sideMenu} />
      </aside>
    );
  }
  
 
  

export default Sidebar;