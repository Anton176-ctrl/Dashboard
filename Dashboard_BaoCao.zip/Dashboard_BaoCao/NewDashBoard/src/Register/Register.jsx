import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import styles from './Register.module.css';

function Register() {
    const [email, setEmail] = useState('');
    const [user, setUser] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault(); // Ngăn chặn trang reload khi submit form

        const data = { email, username: user, password };

        try {
            const response = await axios.post("http://localhost:8080/api/auth/signup", data);
            console.log("Đăng ký thành công:", response.data);
            if (response.status === 200) { // Kiểm tra mã trạng thái
                navigate("/");
            }
        } catch (error) {
            console.error("Lỗi khi đăng ký:", error);
            alert("Đăng ký thất bại! Vui lòng thử lại.");
        }
    };

    return (
        <div className={styles.rootLogin}> 
            <div className={styles.loginContainer}>
                <h1 className={styles.formTitle}>Đăng Ký</h1>
                <form onSubmit={handleSubmit} className={styles.loginForm}>
                    <div className={styles.inputWrapper}> 
                        <input
                            type="text"
                            placeholder="User"
                            value={user}
                            onChange={(e) => setUser(e.target.value)}
                            required
                            className={styles.inputField}
                        />
                         <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6" className={styles.fontCss}>
  <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
</svg>
                    </div>

                    <div className={styles.inputWrapper}> 
                        <input
                            type="email"
                            placeholder="Email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            className={styles.inputField}
                        />
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className={styles.fontCss}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                        </svg>
                    </div>

                    <div className={styles.inputWrapper}>
                        <input
                            type="password"
                            placeholder="Mật khẩu"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            className={styles.inputField}
                        />
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className={styles.fontCss}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                        </svg>
                    </div>

                    <div className={styles.forgotWrapper}>
                        <a href="#" className={styles.forgotPassLink}>Quên mật khẩu?</a>
                        <button type="submit" className={styles.loginButton}>Đăng Ký</button>
                    </div>
                </form>
                <div className={styles.noAccount}>
                    <p className={styles.signupText}>Đã có tài khoản? <a href="/">Đăng nhập ngay</a></p>
                </div>
            </div>
        </div>
    );
}

export default Register;
