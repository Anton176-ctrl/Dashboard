import { useState } from 'react'
import './App.css'
import Main from './dashboard/Main';
import Login from './Login/Login';
import Register from './Register/Register';

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";


function App() {
 

  return (
    <Router>
      <Routes>
          <Route path="/admin" element={<Main />} />
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />


   </Routes>
   </Router>
  )
}

export default App